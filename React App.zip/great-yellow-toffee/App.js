import React, { useState } from 'react';
// importing all UI functions
import { View, Text, TextInput, Button, FlatList, Image, TouchableOpacity, ActivityIndicator } from 'react-native'; 
// this async storage is used to store movies for offline 
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_KEY = "81170fad" ;  // this is the api key of the obdb site
const API_URL = 'https://www.omdbapi.com/'; // urr of the site

const MovieSearchApp = () => {
    const [query, setQuery] = useState('');
    const [movies, setMovies] = useState([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [favorites, setFavorites] = useState([]);


 // This function takes/fetch movie from the omdb site
    const searchMovies = async () => {
        setLoading(true);
        try {
            const response = await fetch(`${API_URL}?s=${query}&apikey=${API_KEY}&page=${page}`);
            const data = await response.json();
            if (data.Search) {
                setMovies(prev => [...prev, ...data.Search]);
            }
        } catch (error) {
            console.error(error);
        }
        setLoading(false);
    };

    const saveFavorite = async (movie) => {
        try {
            const updatedFavorites = [...favorites, movie];
            setFavorites(updatedFavorites);
            await AsyncStorage.setItem('favorites', JSON.stringify(updatedFavorites));
        } catch (error) {
            console.error('Error saving favorite', error);
        }
    };

    return (
        <View style={{ padding: 20 }}>
            <TextInput
                placeholder="Search for a movie"
                value={query}
                onChangeText={setQuery}
                style={{ borderWidth: 1, padding: 10, marginBottom: 10 }}
            />
            <Button title="Search" onPress={searchMovies} />
            <FlatList
                data={movies}
                keyExtractor={(item) => item.imdbID}
                renderItem={({ item }) => (
                    <TouchableOpacity onPress={() => saveFavorite(item)}>
                        <View style={{ flexDirection: 'row', padding: 10 }}>
                            <Image source={{ uri: item.Poster }} style={{ width: 50, height: 75 }} />
                            <Text style={{ marginLeft: 10 }}>{item.Title} ({item.Year})</Text>
                        </View>
                    </TouchableOpacity>
                )}
                onEndReached={() => {
                    setPage(prev => prev + 1);
                    searchMovies();
                }}
                onEndReachedThreshold={0.5}
            />
            {loading && <ActivityIndicator size="large" color="#0000ff" />}
        </View>
    );
};

export default MovieSearchApp;
